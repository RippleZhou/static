<?php
	header("Content-type: text/html; charset=utf-8");
	define('HOST', '192.168.200.5');
	define('USERNAME', 'aidingdb');
	define('PASSWORD', 'Aa123456');
?>