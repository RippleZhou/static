<?php
define('DATABASE_USERNAME','aidingdb');
define('DATABASE_PASSWORD','Aa123456');
